﻿using HospiVital.Mocks;
using HospiVital.Models;
using HospiVital.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HospiVital.Controllers
{
    [Authorize]
    [Route("Inventario")]
    public class InventarioController : Controller
    {
        private static readonly inventario _inventario = new inventario();
        private static readonly object _lock = new();
        private static bool _seeded = false;
        private static int _donanteId = 1;

        [HttpGet("GenerarCodigo")]
        public IActionResult GenerarCodigo()
        {
            EnsureSeed();

            Random random = new Random();

            string anio = DateTime.Now.Year.ToString("D2");
            string numeroUnico = random.Next(1000000).ToString("D6");
            string segundos = DateTime.Now.Second.ToString("D2");

            string codigo = $"HP{anio}{numeroUnico}{segundos}";
            return Content(codigo);
        }

        [HttpGet("Listar")]
        public IActionResult Listar()
        {
            EnsureSeed();

            lock (_lock)
            {
                var lista = _inventario.listaDisponibles()
                    .Select(u => new
                    {
                        IdUnidad = u.IdUnidad,
                        NombreDonante = $"{u.Donante?.Nombre} {u.Donante?.Apellido}".Trim(),
                        TipoSangre = $"{u.TipoSangre}{u.FactorRh}",
                        FechaIngreso = u.FechaIngreso,
                        FechaVencimiento = u.FechaCaducidad,
                        Estado = u.estaVencida() ? "Vencido" : "Activo",
                        Dui = u.Donante?.Dui ?? "",
                        Telefono = u.Donante?.Telefono ?? ""
                    })
                    .ToList();

                return Json(lista);
            }
        }

        [HttpPost("Registrar")]
        public IActionResult Registrar([FromBody] RegistrarUnidadRequest request)
        {
            EnsureSeed();

            try
            {
                if (request == null)
                    return BadRequest(new { mensaje = "Solicitud inválida." });

                if (string.IsNullOrWhiteSpace(request.IdUnidad) ||
                    string.IsNullOrWhiteSpace(request.NombreCompleto) ||
                    string.IsNullOrWhiteSpace(request.Dui) ||
                    string.IsNullOrWhiteSpace(request.Telefono) ||
                    string.IsNullOrWhiteSpace(request.TipoSangre))
                {
                    return BadRequest(new { mensaje = "Faltan campos obligatorios." });
                }

                if (request.FechaRegistro == default)
                {
                    return BadRequest(new { mensaje = "La fecha de registro es inválida." });
                }

                var (tipo, rh) = SepararTipoYRh(request.TipoSangre);
                var (nombre, apellido) = SepararNombre(request.NombreCompleto);

                var donante = new Donante(
                    _donanteId++,
                    nombre,
                    apellido,
                    request.Dui,
                    request.Telefono
                );

                var fechaIngreso = request.FechaRegistro.Date;
                var fechaCaducidad = fechaIngreso.AddDays(35);

                var unidad = new unidadDeSangre(
                    request.IdUnidad,
                    tipo,
                    rh,
                    fechaIngreso,
                    fechaCaducidad,
                    "Disponible",
                    500,
                    donante
                );

                lock (_lock)
                {
                    _inventario.agregarUnidad(unidad);
                }

                return Ok(new
                {
                    ok = true,
                    mensaje = "Unidad registrada correctamente."
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    mensaje = $"Error al registrar: {ex.Message}"
                });
            }
        }
        private static void EnsureSeed()
        {
            if (_seeded) return;

            lock (_lock)
            {
                if (_seeded) return;

                var mock = InventarioMockData.Get();

                foreach (var item in mock.Unidades)
                {
                    var (tipo, rh) = SepararTipoYRh(item.TipoSangre);
                    var (nombre, apellido) = SepararNombre(item.NombreDonante);

                    var donante = new Donante(
                        _donanteId++,
                        nombre,
                        apellido,
                        item.Dui,
                        item.Telefono
                    );

                    var unidad = new unidadDeSangre(
                        item.IdUnidad,
                        tipo,
                        rh,
                        item.FechaIngreso,
                        item.FechaVencimiento,
                        item.Estado,
                        500,
                        donante
                    );

                    _inventario.agregarUnidad(unidad);
                }

                _seeded = true;
            }
        }

        private static (string tipo, string rh) SepararTipoYRh(string tipoCompleto)
        {
            if (string.IsNullOrWhiteSpace(tipoCompleto))
                return ("", "");

            if (tipoCompleto.EndsWith("+") || tipoCompleto.EndsWith("-"))
                return (tipoCompleto[..^1], tipoCompleto[^1].ToString());

            return (tipoCompleto, "");
        }

        private static (string nombre, string apellido) SepararNombre(string nombreCompleto)
        {
            if (string.IsNullOrWhiteSpace(nombreCompleto))
                return ("", "");

            var partes = nombreCompleto.Trim()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries);

            if (partes.Length == 1)
                return (partes[0], "");

            return (partes[0], string.Join(" ", partes.Skip(1)));
        }
    }
}