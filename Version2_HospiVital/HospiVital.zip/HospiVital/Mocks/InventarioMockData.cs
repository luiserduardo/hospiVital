﻿using HospiVital.ViewModels;

namespace HospiVital.Mocks
{
    public static class InventarioMockData
    {
        public static InventarioPageViewModel Get()
        {
            var hoy = DateTime.Today;

            var unidades = new List<InventarioItemViewModel>
            {
                new()
                {
                    IdUnidad = "B-0955-AB",
                    NombreDonante = "Ana López",
                    TipoSangre = "AB-",
                    FechaIngreso = hoy.AddDays(-35),
                    FechaVencimiento = hoy.AddDays(-5),
                    Estado = "Vencido",
                    Dui = "01234567-8",
                    Telefono = "7000-0001"
                },
                new()
                {
                    IdUnidad = "B-0988-O",
                    NombreDonante = "Mario Cruz",
                    TipoSangre = "O-",
                    FechaIngreso = hoy.AddDays(-30),
                    FechaVencimiento = hoy.AddDays(-1),
                    Estado = "Vencido",
                    Dui = "12345678-9",
                    Telefono = "7000-0002"
                },
                new()
                {
                    IdUnidad = "B-1024-A",
                    NombreDonante = "Eduardo Orantes",
                    TipoSangre = "A+",
                    FechaIngreso = hoy.AddDays(-10),
                    FechaVencimiento = hoy.AddDays(15),
                    Estado = "Activo",
                    Dui = "00000000-0",
                    Telefono = "7000-0000"
                },
                new()
                {
                    IdUnidad = "B-1025-B",
                    NombreDonante = "Rosa Pérez",
                    TipoSangre = "B+",
                    FechaIngreso = hoy.AddDays(-8),
                    FechaVencimiento = hoy.AddDays(17),
                    Estado = "Activo",
                    Dui = "23456789-0",
                    Telefono = "7000-0003"
                },
                new()
                {
                    IdUnidad = "B-1026-AB",
                    NombreDonante = "Luis Ramos",
                    TipoSangre = "AB+",
                    FechaIngreso = hoy.AddDays(-7),
                    FechaVencimiento = hoy.AddDays(18),
                    Estado = "Activo",
                    Dui = "34567890-1",
                    Telefono = "7000-0004"
                },
                new()
                {
                    IdUnidad = "B-1032-O",
                    NombreDonante = "Carmen Díaz",
                    TipoSangre = "O-",
                    FechaIngreso = hoy.AddDays(-4),
                    FechaVencimiento = hoy.AddDays(20),
                    Estado = "Activo",
                    Dui = "45678901-2",
                    Telefono = "7000-0005"
                },
                new()
                {
                    IdUnidad = "B-1035-O",
                    NombreDonante = "Jorge Méndez",
                    TipoSangre = "O+",
                    FechaIngreso = hoy,
                    FechaVencimiento = hoy.AddDays(22),
                    Estado = "Activo",
                    Dui = "56789012-3",
                    Telefono = "7000-0006"
                },
                new()
                {
                    IdUnidad = "B-1040-A",
                    NombreDonante = "María Flores",
                    TipoSangre = "A-",
                    FechaIngreso = hoy,
                    FechaVencimiento = hoy.AddDays(19),
                    Estado = "Activo",
                    Dui = "67890123-4",
                    Telefono = "7000-0007"
                },
                new()
                {
                    IdUnidad = "B-1041-B",
                    NombreDonante = "Juan Herrera",
                    TipoSangre = "B-",
                    FechaIngreso = hoy.AddDays(-1),
                    FechaVencimiento = hoy.AddDays(21),
                    Estado = "Activo",
                    Dui = "78901234-5",
                    Telefono = "7000-0008"
                },
                new()
                {
                    IdUnidad = "B-1042-O",
                    NombreDonante = "Patricia Rivas",
                    TipoSangre = "O+",
                    FechaIngreso = hoy.AddDays(-2),
                    FechaVencimiento = hoy.AddDays(25),
                    Estado = "Activo",
                    Dui = "89012345-6",
                    Telefono = "7000-0009"
                },
                new()
                {
                    IdUnidad = "B-1043-A",
                    NombreDonante = "Elena Castro",
                    TipoSangre = "A+",
                    FechaIngreso = hoy.AddDays(-3),
                    FechaVencimiento = hoy.AddDays(26),
                    Estado = "Activo",
                    Dui = "90123456-7",
                    Telefono = "7000-0010"
                },
                new()
                {
                    IdUnidad = "B-1044-AB",
                    NombreDonante = "Carlos Peña",
                    TipoSangre = "AB-",
                    FechaIngreso = hoy.AddDays(-6),
                    FechaVencimiento = hoy.AddDays(13),
                    Estado = "Activo",
                    Dui = "11223344-5",
                    Telefono = "7000-0011"
                }
            };

            foreach (var unidad in unidades)
            {
                unidad.Estado = unidad.FechaVencimiento < hoy ? "Vencido" : "Activo";
            }

            var totalUnidades = unidades.Count;
            var stockDisponible = unidades.Count(x => x.Estado == "Activo");
            var bolsasVencidas = unidades.Count(x => x.Estado == "Vencido");
            var donacionesHoy = unidades.Count(x => x.FechaIngreso.Date == hoy);

            var stockEstado = "Crítico";
            var stockEstadoClase = "danger";

            if (stockDisponible > 20)
            {
                stockEstado = "Bueno";
                stockEstadoClase = "success";
            }
            else if (stockDisponible > 10)
            {
                stockEstado = "Intermedio";
                stockEstadoClase = "warning";
            }

            return new InventarioPageViewModel
            {
                TotalUnidades = totalUnidades,
                StockDisponible = stockDisponible,
                StockEstado = stockEstado,
                StockEstadoClase = stockEstadoClase,
                BolsasVencidas = bolsasVencidas,
                DonacionesHoy = donacionesHoy,
                Unidades = unidades
            };
        }
    }
}