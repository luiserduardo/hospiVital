﻿namespace HospiVital.ViewModels
{
    public class InventarioItemViewModel
    {
        public string IdUnidad { get; set; } = string.Empty;
        public string NombreDonante { get; set; } = string.Empty;
        public string TipoSangre { get; set; } = string.Empty;
        public DateTime FechaIngreso { get; set; }
        public DateTime FechaVencimiento { get; set; }
        public string Estado { get; set; } = string.Empty;

        public string Dui { get; set; } = string.Empty;
        public string Telefono { get; set; } = string.Empty;


    }

}