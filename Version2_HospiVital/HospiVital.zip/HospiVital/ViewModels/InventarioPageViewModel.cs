﻿namespace HospiVital.ViewModels
{
    public class InventarioPageViewModel
    {
        public int TotalUnidades { get; set; }
        public int StockDisponible { get; set; }
        public string StockEstado { get; set; } = string.Empty;
        public string StockEstadoClase { get; set; } = string.Empty;

        public int BolsasVencidas { get; set; }
        public int DonacionesHoy { get; set; }

        public List<InventarioItemViewModel> Unidades { get; set; } = new();
    }
}