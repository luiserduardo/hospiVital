﻿namespace HospiVital.ViewModels
{
    public class RegistrarUnidadRequest
    {
        public string IdUnidad { get; set; } = string.Empty;
        public string NombreCompleto { get; set; } = string.Empty;
        public string Dui { get; set; } = string.Empty;
        public string Telefono { get; set; } = string.Empty;
        public string TipoSangre { get; set; } = string.Empty;
        public DateTime FechaRegistro { get; set; }
    }
}