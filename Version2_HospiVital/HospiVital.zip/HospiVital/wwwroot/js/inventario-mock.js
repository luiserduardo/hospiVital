﻿document.addEventListener("DOMContentLoaded", function () {
    const seedElement = document.getElementById("inventario-seed");
    const seed = seedElement ? JSON.parse(seedElement.textContent) : [];

    const searchInput = document.getElementById("inventarioSearch");
    const tbody = document.getElementById("inventarioTableBody");
    const countLabel = document.getElementById("inventarioCount");

    const totalLabel = document.getElementById("statTotalUnidades");
    const stockLabel = document.getElementById("statStockLabel");
    const stockValue = document.getElementById("statStockDisponible");
    const stockIcon = document.getElementById("statStockIcon");
    const expiredLabel = document.getElementById("statBolsasVencidas");
    const todayLabel = document.getElementById("statDonacionesHoy");

    const btnToggleFiltros = document.getElementById("btnToggleFiltros");
    const btnAplicarFiltros = document.getElementById("btnAplicarFiltros");
    const btnLimpiarFiltros = document.getElementById("btnLimpiarFiltros");
    const filterPanel = document.getElementById("inventarioFilterPanel");
    const filterFecha = document.getElementById("filterFecha");
    const filterEstado = document.getElementById("filterEstado");
    const bloodFilterGrid = document.getElementById("bloodFilterGrid");

    const btnAbrirDonacion = document.getElementById("btnAbrirDonacion");
    const btnCerrarDonacion = document.getElementById("btnCerrarDonacion");
    const btnCancelarDonacion = document.getElementById("btnCancelarDonacion");
    const modalBackdrop = document.getElementById("inventarioModalBackdrop");
    const form = document.getElementById("inventarioDonacionForm");
    const formError = document.getElementById("inventarioFormError");

    const donorIdInput = document.getElementById("donanteId");
    const fechaRegistroInput = document.getElementById("fechaRegistro");
    const nombreCompletoInput = document.getElementById("nombreCompleto");
    const duiInput = document.getElementById("dui");
    const telefonoInput = document.getElementById("telefono");
    const pesoInput = document.getElementById("peso");
    const tipoSangreInput = document.getElementById("tipoSangreDonacion");
    const listaExcluyentesInput = document.getElementById("listaExcluyentes");

    const btnPrevPage = document.getElementById("btnPrevPage");
    const btnNextPage = document.getElementById("btnNextPage");

    const detallesBackdrop = document.getElementById("inventarioDetallesBackdrop");
    const btnCerrarDetalles = document.getElementById("btnCerrarDetalles");

    const detalleSubtitulo = document.getElementById("detalleSubtitulo");
    const detalleIdUnidad = document.getElementById("detalleIdUnidad");
    const detalleTipoSangre = document.getElementById("detalleTipoSangre");
    const detalleFechaIngreso = document.getElementById("detalleFechaIngreso");
    const detalleNombre = document.getElementById("detalleNombre");
    const detalleDui = document.getElementById("detalleDui");
    const detalleFechaVencimiento = document.getElementById("detalleFechaVencimiento");
    const detalleTelefono = document.getElementById("detalleTelefono");

    const pageSize = 6;
    let currentPage = 1;
    let generatedServerCode = "";

    let filters = {
        search: "",
        fecha: "all",
        estado: "all",
        sangre: ""
    };

    let unidades = seed.map(normalizeUnit);

    async function fetchUnitsFromServer() {
        const response = await fetch("/Inventario/Listar", {
            method: "GET",
            headers: {
                "X-Requested-With": "XMLHttpRequest"
            }
        });

        if (!response.ok) {
            throw new Error("No se pudo cargar el inventario.");
        }

        const data = await response.json();
        return data.map(normalizeUnit);
    }

    async function fetchGeneratedCode() {
        const response = await fetch("/Inventario/GenerarCodigo", {
            method: "GET",
            headers: {
                "X-Requested-With": "XMLHttpRequest"
            }
        });

        if (!response.ok) {
            throw new Error("No se pudo generar el código.");
        }

        return (await response.text()).trim();
    }

    function parseDateValue(value) {
        if (!value) return null;

        if (value instanceof Date) {
            return Number.isNaN(value.getTime()) ? null : value;
        }

        if (typeof value === "number") {
            const date = new Date(value);
            return Number.isNaN(date.getTime()) ? null : date;
        }

        if (typeof value !== "string") return null;

        const text = value.trim();
        if (!text) return null;

        let date = new Date(text);
        if (!Number.isNaN(date.getTime())) {
            return date;
        }

        let match = text.match(/\/Date\((\d+)\)\//);
        if (match) {
            date = new Date(Number(match[1]));
            return Number.isNaN(date.getTime()) ? null : date;
        }

        match = text.match(/^(\d{4})-(\d{2})-(\d{2})(?:[T\s].*)?$/);
        if (match) {
            const [, y, m, d] = match;
            date = new Date(Number(y), Number(m) - 1, Number(d));
            return Number.isNaN(date.getTime()) ? null : date;
        }

        match = text.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})(?:[T\s].*)?$/);
        if (match) {
            const [, d, m, y] = match;
            date = new Date(Number(y), Number(m) - 1, Number(d));
            return Number.isNaN(date.getTime()) ? null : date;
        }

        return null;
    }

    function toIsoDate(value) {
        const date = parseDateValue(value);
        return date ? date.toISOString() : null;
    }

    function computeEstado(fechaVencimiento) {
        const vencDate = parseDateValue(fechaVencimiento);
        if (!vencDate) return "Activo";

        const hoy = startOfDay(new Date());
        const venc = startOfDay(vencDate);
        return venc < hoy ? "Vencido" : "Activo";
    }

    function startOfDay(date) {
        const parsed = parseDateValue(date);
        const d = parsed ? new Date(parsed) : new Date();
        d.setHours(0, 0, 0, 0);
        return d;
    }

    function formatDate(value) {
        const date = parseDateValue(value);
        if (!date) return "-";

        return new Intl.DateTimeFormat("en-GB", {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }).format(date);
    }

    function formatDateForInput(date) {
        const d = parseDateValue(date) || new Date();
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, "0");
        const day = String(d.getDate()).padStart(2, "0");
        return `${year}-${month}-${day}`;
    }

    function normalizeUnit(item) {
        const idUnidad = item.IdUnidad ?? item.idUnidad ?? "";
        const nombreDonante = item.NombreDonante ?? item.nombreDonante ?? "";
        const tipoSangre = item.TipoSangre ?? item.tipoSangre ?? "";
        const fechaIngresoRaw = item.FechaIngreso ?? item.fechaIngreso ?? null;
        const fechaVencimientoRaw = item.FechaVencimiento ?? item.fechaVencimiento ?? null;
        const dui = item.Dui ?? item.dui ?? "";
        const telefono = item.Telefono ?? item.telefono ?? "";
        const estadoRaw = item.Estado ?? item.estado ?? "";

        const fechaIngreso = toIsoDate(fechaIngresoRaw);
        const fechaVencimiento = toIsoDate(fechaVencimientoRaw);

        return {
            IdUnidad: idUnidad,
            NombreDonante: nombreDonante,
            TipoSangre: tipoSangre,
            FechaIngreso: fechaIngreso,
            FechaVencimiento: fechaVencimiento,
            Estado: fechaVencimiento ? computeEstado(fechaVencimiento) : (estadoRaw || "Activo"),
            Dui: dui,
            Telefono: telefono
        };
    }

    function getBloodBadgeClass(tipo) {
        switch (tipo) {
            case "A+":
            case "A-":
                return "badge-blue";
            case "B+":
            case "B-":
                return "badge-primary";
            case "AB+":
            case "AB-":
                return "badge-pink";
            case "O+":
                return "badge-orange";
            case "O-":
                return "badge-red";
            default:
                return "badge-warning";
        }
    }

    function getFilteredRows() {
        const hoy = startOfDay(new Date());

        return unidades.filter(item => {
            const searchText = `${item.IdUnidad} ${item.NombreDonante} ${item.TipoSangre}`.toLowerCase();
            const matchesSearch = searchText.includes(filters.search);

            const matchesEstado = filters.estado === "all" || item.Estado === filters.estado;
            const matchesSangre = !filters.sangre || item.TipoSangre === filters.sangre;

            const ingresoDate = parseDateValue(item.FechaIngreso);
            const ingreso = ingresoDate ? startOfDay(ingresoDate) : null;
            let matchesFecha = true;

            if (filters.fecha === "today") {
                matchesFecha = ingreso ? ingreso.getTime() === hoy.getTime() : false;
            } else if (filters.fecha === "last7") {
                const min = new Date(hoy);
                min.setDate(min.getDate() - 7);
                matchesFecha = ingreso ? (ingreso >= min && ingreso <= hoy) : false;
            } else if (filters.fecha === "last30") {
                const min = new Date(hoy);
                min.setDate(min.getDate() - 30);
                matchesFecha = ingreso ? (ingreso >= min && ingreso <= hoy) : false;
            }

            return matchesSearch && matchesEstado && matchesSangre && matchesFecha;
        });
    }

    function renderTable() {
        const rows = getFilteredRows();
        const totalFiltered = rows.length;
        const totalPages = Math.max(1, Math.ceil(totalFiltered / pageSize));

        if (currentPage > totalPages) {
            currentPage = totalPages;
        }

        const startIndex = (currentPage - 1) * pageSize;
        const pagedRows = rows.slice(startIndex, startIndex + pageSize);

        if (pagedRows.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" style="text-align:center; padding:24px; color:var(--muted);">
                        No se encontraron resultados.
                    </td>
                </tr>
            `;
            countLabel.textContent = `Mostrando 0 de ${totalFiltered}`;
            updatePaginationButtons(totalPages);
            return;
        }

        tbody.innerHTML = pagedRows.map(item => {
            const rowClass = item.Estado === "Vencido" ? "row-expired" : "";
            const bloodBadge = getBloodBadgeClass(item.TipoSangre);
            const statusBadge = item.Estado === "Activo" ? "badge-success" : "badge-danger";
            const fechaVencClass = item.Estado === "Vencido" ? "date-expired" : "";

            return `
                <tr class="${rowClass}">
                    <td class="unit-code">${item.IdUnidad}</td>
                    <td><span class="badge-soft ${bloodBadge}">${item.TipoSangre}</span></td>
                    <td>${formatDate(item.FechaIngreso)}</td>
                    <td class="${fechaVencClass}">${formatDate(item.FechaVencimiento)}</td>
                    <td><span class="badge-soft ${statusBadge}">${item.Estado}</span></td>
                    <td class="actions-cell">
                        <div class="actions-dropdown">
                            <button type="button" class="actions-menu" data-action-toggle="${item.IdUnidad}">⋮</button>
                            <div class="actions-popover" data-action-menu="${item.IdUnidad}">
                                <button type="button" class="actions-popover-item" data-view-detail="${item.IdUnidad}">
                                    Ver detalles
                                </button>
                            </div>
                        </div>
                    </td>
                </tr>
            `;
        }).join("");

        const from = startIndex + 1;
        const to = Math.min(startIndex + pageSize, totalFiltered);
        countLabel.textContent = `Mostrando ${from}-${to} de ${totalFiltered}`;
        updatePaginationButtons(totalPages);
    }

    function updatePaginationButtons(totalPages) {
        if (!btnPrevPage || !btnNextPage) return;

        btnPrevPage.disabled = currentPage <= 1;
        btnNextPage.disabled = currentPage >= totalPages;

        btnPrevPage.classList.toggle("disabled", btnPrevPage.disabled);
        btnNextPage.classList.toggle("disabled", btnNextPage.disabled);
    }

    function renderStats() {
        const hoy = startOfDay(new Date());

        const total = unidades.length;
        const stockDisponible = unidades.filter(x => x.Estado === "Activo").length;
        const vencidas = unidades.filter(x => x.Estado === "Vencido").length;
        const hoyCount = unidades.filter(x => {
            const ingreso = parseDateValue(x.FechaIngreso);
            return ingreso ? startOfDay(ingreso).getTime() === hoy.getTime() : false;
        }).length;

        let estado = "Crítico";
        let clase = "danger";
        let icon = "⚠";

        if (stockDisponible > 20) {
            estado = "Bueno";
            clase = "success";
            icon = "✔";
        } else if (stockDisponible > 10) {
            estado = "Intermedio";
            clase = "warning";
            icon = "⌛";
        }

        totalLabel.textContent = total;
        stockLabel.textContent = `Stock ${estado}`;
        stockValue.textContent = `${stockDisponible} unidades`;
        stockValue.className = clase === "danger" ? "danger-number" : "";
        stockIcon.className = `stat-icon ${clase}`;
        stockIcon.textContent = icon;
        expiredLabel.textContent = vencidas;
        todayLabel.textContent = hoyCount;
    }

    function renderAll() {
        unidades = unidades.map(item => ({
            ...item,
            Estado: item.FechaVencimiento ? computeEstado(item.FechaVencimiento) : (item.Estado || "Activo")
        }));

        renderStats();
        renderTable();
    }

    async function refreshFromServer() {
        const data = await fetchUnitsFromServer();
        unidades = data;
        renderAll();
    }

    function toggleFilterPanel(forceClose = false) {
        if (forceClose) {
            filterPanel.classList.remove("open");
            return;
        }
        filterPanel.classList.toggle("open");
    }

    function clearFilters() {
        filters.fecha = "all";
        filters.estado = "all";
        filters.sangre = "";
        filterFecha.value = "all";
        filterEstado.value = "all";

        document.querySelectorAll(".blood-filter-chip").forEach(btn => {
            btn.classList.remove("active");
        });

        currentPage = 1;
        renderTable();
    }

    async function prepareModalDefaults() {
        form.reset();
        formError.style.display = "none";
        formError.textContent = "";
        listaExcluyentesInput.value = "";
        tipoSangreInput.value = "";

        generatedServerCode = "";
        donorIdInput.value = "Generando...";
        fechaRegistroInput.value = formatDateForInput(new Date());

        const defaults = {
            desayunoHoy: "Si",
            durmioSeisHoras: "Si",
            consumoAlcohol: "No",
            tatuajesRecientes: "No",
            enfermedadCronica: "No"
        };

        Object.entries(defaults).forEach(([id, value]) => {
            const hidden = document.getElementById(id);
            if (hidden) hidden.value = value;
        });

        document.querySelectorAll(".toggle-group").forEach(group => {
            const buttons = group.querySelectorAll(".toggle-option");
            const hidden = document.getElementById(group.dataset.target);
            const currentValue = hidden ? hidden.value : "Si";

            buttons.forEach(btn => {
                btn.classList.toggle("active", btn.dataset.value === currentValue);
            });
        });

        try {
            generatedServerCode = await fetchGeneratedCode();
            donorIdInput.value = generatedServerCode;
        } catch {
            donorIdInput.value = "No se pudo generar ID";
        }
    }

    function openModal() {
        modalBackdrop.classList.add("open");
        prepareModalDefaults();
    }

    function closeModal() {
        modalBackdrop.classList.remove("open");
    }

    function getEffectiveDonorId() {
        return generatedServerCode || donorIdInput.value.trim();
    }

    function normalizeDui(value) {
        const digits = value.replace(/\D/g, "").slice(0, 9);
        if (digits.length <= 8) return digits;
        return `${digits.slice(0, 8)}-${digits.slice(8)}`;
    }

    function normalizePhone(value) {
        const digits = value.replace(/\D/g, "").slice(0, 8);
        if (digits.length <= 4) return digits;
        return `${digits.slice(0, 4)}-${digits.slice(4)}`;
    }

    function isValidDui(value) {
        return /^\d{8}-\d$/.test(value);
    }

    function isValidPhone(value) {
        return /^\d{4}-\d{4}$/.test(value);
    }

    function validateDonationForm() {
        const donorId = getEffectiveDonorId();
        const fechaRegistro = fechaRegistroInput.value.trim();
        const nombre = nombreCompletoInput.value.trim();
        const dui = duiInput.value.trim();
        const telefono = telefonoInput.value.trim();
        const peso = Number(pesoInput.value);
        const tipo = tipoSangreInput.value;

        const desayuno = document.getElementById("desayunoHoy").value;
        const durmio = document.getElementById("durmioSeisHoras").value;
        const alcohol = document.getElementById("consumoAlcohol").value;
        const tatuajes = document.getElementById("tatuajesRecientes").value;
        const enfermedad = document.getElementById("enfermedadCronica").value;
        const excluyente = listaExcluyentesInput.value;

        if (!donorId || !fechaRegistro || !nombre || !dui || !telefono || !peso || !tipo) {
            return "Complete todos los campos obligatorios.";
        }

        if (!generatedServerCode) {
            return "No se pudo generar el ID del donante. Intente nuevamente.";
        }

        if (!isValidDui(dui)) {
            return "El DUI debe tener el formato 00000000-0.";
        }

        if (!isValidPhone(telefono)) {
            return "El teléfono debe tener el formato 0000-0000.";
        }

        if (peso < 50) {
            return "El donante debe pesar al menos 50 kg.";
        }

        if (desayuno !== "Si" || durmio !== "Si") {
            return "El donante debe haber desayunado y dormido al menos 6 horas.";
        }

        if (alcohol === "Si" || tatuajes === "Si" || enfermedad === "Si" || excluyente) {
            return "El donante no cumple los criterios de elegibilidad.";
        }

        return "";
    }

    async function handleAddDonation(e) {
        e.preventDefault();

        const validationMessage = validateDonationForm();

        if (validationMessage) {
            formError.textContent = validationMessage;
            formError.style.display = "block";
            return;
        }

        const payload = {
            idUnidad: getEffectiveDonorId(),
            nombreCompleto: nombreCompletoInput.value.trim(),
            dui: duiInput.value.trim(),
            telefono: telefonoInput.value.trim(),
            tipoSangre: tipoSangreInput.value,
            fechaRegistro: fechaRegistroInput.value
        };

        console.log("Payload enviado:", payload);

        try {
            const response = await fetch("/Inventario/Registrar", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-Requested-With": "XMLHttpRequest"
                },
                body: JSON.stringify(payload)
            });

            const rawText = await response.text();
            console.log("Status Registrar:", response.status);
            console.log("Respuesta Registrar:", rawText);

            let result = null;
            try {
                result = rawText ? JSON.parse(rawText) : null;
            } catch {
                result = null;
            }

            if (!response.ok) {
                formError.textContent = result?.mensaje || "No se pudo registrar la unidad.";
                formError.style.display = "block";
                return;
            }

            currentPage = 1;
            closeModal();

            try {
                await refreshFromServer();
            } catch (error) {
                console.error("Error refrescando inventario:", error);
                formError.textContent = "Se registró, pero no se pudo refrescar la lista.";
                formError.style.display = "block";
            }
        } catch (error) {
            console.error("Error en Registrar:", error);
            formError.textContent = "Error de conexión al registrar la unidad.";
            formError.style.display = "block";
        }
    }

    function openDetailsModal(item) {
        detalleSubtitulo.textContent = `ID: ${item.IdUnidad}`;
        detalleIdUnidad.textContent = item.IdUnidad;

        const bloodBadge = getBloodBadgeClass(item.TipoSangre);
        detalleTipoSangre.innerHTML = `<span class="badge-soft ${bloodBadge}">${item.TipoSangre}</span>`;

        detalleFechaIngreso.textContent = formatDate(item.FechaIngreso);
        detalleNombre.textContent = item.NombreDonante || "-";
        detalleDui.textContent = item.Dui || "-";
        detalleFechaVencimiento.textContent = formatDate(item.FechaVencimiento);
        detalleTelefono.textContent = item.Telefono ? `+503 ${item.Telefono}` : "-";

        detallesBackdrop.classList.add("open");
    }

    function closeDetailsModal() {
        detallesBackdrop.classList.remove("open");
    }

    function closeAllActionMenus() {
        document.querySelectorAll(".actions-popover.open").forEach(menu => {
            menu.classList.remove("open");
        });
    }

    duiInput.addEventListener("input", function () {
        this.value = normalizeDui(this.value);
    });

    telefonoInput.addEventListener("input", function () {
        this.value = normalizePhone(this.value);
    });

    document.querySelectorAll(".toggle-group").forEach(group => {
        const hidden = document.getElementById(group.dataset.target);

        group.querySelectorAll(".toggle-option").forEach(button => {
            button.addEventListener("click", function () {
                group.querySelectorAll(".toggle-option").forEach(btn => btn.classList.remove("active"));
                this.classList.add("active");
                hidden.value = this.dataset.value;
            });
        });
    });

    searchInput.addEventListener("input", function () {
        filters.search = this.value.trim().toLowerCase();
        currentPage = 1;
        renderTable();
    });

    btnToggleFiltros.addEventListener("click", function (e) {
        e.stopPropagation();
        toggleFilterPanel();
    });

    btnAplicarFiltros.addEventListener("click", function () {
        filters.fecha = filterFecha.value;
        filters.estado = filterEstado.value;
        currentPage = 1;
        toggleFilterPanel(true);
        renderTable();
    });

    btnLimpiarFiltros.addEventListener("click", function () {
        clearFilters();
        toggleFilterPanel(true);
    });

    bloodFilterGrid.querySelectorAll(".blood-filter-chip").forEach(button => {
        button.addEventListener("click", function () {
            const value = this.dataset.blood;

            if (filters.sangre === value) {
                filters.sangre = "";
                this.classList.remove("active");
            } else {
                filters.sangre = value;
                bloodFilterGrid.querySelectorAll(".blood-filter-chip").forEach(btn => btn.classList.remove("active"));
                this.classList.add("active");
            }
        });
    });

    btnPrevPage?.addEventListener("click", function () {
        if (currentPage > 1) {
            currentPage--;
            renderTable();
        }
    });

    btnNextPage?.addEventListener("click", function () {
        const totalFiltered = getFilteredRows().length;
        const totalPages = Math.max(1, Math.ceil(totalFiltered / pageSize));

        if (currentPage < totalPages) {
            currentPage++;
            renderTable();
        }
    });

    btnAbrirDonacion.addEventListener("click", openModal);
    btnCerrarDonacion.addEventListener("click", closeModal);
    btnCancelarDonacion.addEventListener("click", closeModal);
    form.addEventListener("submit", handleAddDonation);

    modalBackdrop.addEventListener("click", function (e) {
        if (e.target === modalBackdrop) {
            closeModal();
        }
    });

    tbody.addEventListener("click", function (e) {
        const toggleBtn = e.target.closest("[data-action-toggle]");
        const detailBtn = e.target.closest("[data-view-detail]");

        if (toggleBtn) {
            const id = toggleBtn.dataset.actionToggle;
            const menu = document.querySelector(`[data-action-menu="${id}"]`);

            const wasOpen = menu.classList.contains("open");
            closeAllActionMenus();

            if (!wasOpen) {
                menu.classList.add("open");
            }
            return;
        }

        if (detailBtn) {
            const id = detailBtn.dataset.viewDetail;
            const item = unidades.find(x => x.IdUnidad === id);

            closeAllActionMenus();

            if (item) {
                openDetailsModal(item);
            }
        }
    });

    btnCerrarDetalles?.addEventListener("click", closeDetailsModal);

    detallesBackdrop?.addEventListener("click", function (e) {
        if (e.target === detallesBackdrop) {
            closeDetailsModal();
        }
    });

    document.addEventListener("click", function (e) {
        if (!e.target.closest(".inventario-filter-wrap")) {
            toggleFilterPanel(true);
        }

        if (!e.target.closest(".actions-dropdown")) {
            closeAllActionMenus();
        }
    });

    renderAll();

    refreshFromServer().catch((error) => {
        console.error("Error al cargar inventario:", error);
        // se deja visible el seed inicial si el backend falla
    });
});