using HospiVital_App.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HospiVital_App.Controllers
{
    [Authorize(Roles = AppRoles.Admin)]
    public class vialesVencidosController : Controller
    {
        [HttpGet]
        public IActionResult obtenerListado()
        {
            return View();
        }
    }
}
